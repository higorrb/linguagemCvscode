#include <stdio.h>

int main()
{
    int i;

    printf("Contagem 10->1:\n");
    for(i=10; i>0; i--){
        printf("%i \n", i);
    }

    return 0;
}